import { Metadata } from "next";
import { EnrollmentForm } from "./form";
import { getAdmissionYear } from "@/lib/dateUtils";

export async function generateMetadata(): Promise<Metadata> {
  const year = getAdmissionYear();
  return {
    title: `Inscripciones ${year} | Fundación Educativa Esquel`,
    description: `Formulario de admisión para el ciclo lectivo ${year}.`,
  };
}

export default function InscripcionesPage() {
  const year = getAdmissionYear();
  
  return (
    <div className="bg-background pb-24">
      {/* Header */}
      <section className="pt-32 pb-20 bg-brand-green text-white relative">
        <div className="container mx-auto px-6 lg:px-12 text-center relative z-10">
          <span className="text-brand-yellow font-bold uppercase tracking-widest text-sm mb-4 block">
            Admisión {year}
          </span>
          <h1 className="text-5xl md:text-6xl font-bold mb-6 max-w-4xl mx-auto leading-tight">
            Postulación de Vacantes
          </h1>
          <p className="text-xl max-w-2xl mx-auto opacity-90 leading-relaxed font-medium">
            Completa el siguiente formulario para iniciar el proceso de postulación a los niveles Inicial, Primario o Secundario.
          </p>
        </div>
      </section>

      {/* Form Container */}
      <section className="py-16 -mt-12 relative z-20">
        <div className="container mx-auto px-6 lg:px-12 max-w-4xl">
          <div className="bg-white rounded-[2rem] p-8 md:p-12 shadow-2xl border border-brand-gray/10">
            <h2 className="text-3xl font-bold text-brand-blue mb-8 border-b pb-4">
              Datos del Aspirante ({year})
            </h2>
            <EnrollmentForm />
          </div>
        </div>
      </section>

    </div>
  );
}
