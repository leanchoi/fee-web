import { notFound } from "next/navigation";
import { Metadata } from "next";

const nivelesData = {
  inicial: {
    title: "Nivel Inicial",
    subtitle: "Salas de 3, 4 y 5 años. Aprendizaje basado en el juego y la exploración natural.",
    color: "brand-yellow",
    content: [
      {
        heading: "Eje central: el juego",
        text: "El juego es el motor del aprendizaje: potencia la creatividad, la imaginación y la comprensión del mundo.",
      },
      {
        heading: "Objetivos principales",
        text: "• Favorecer la socialización\n• Desarrollar hábitos y rutinas\n• Estimular la curiosidad\n• Acompañar el desarrollo integral",
      },
      {
        heading: "Perfil del egresado",
        text: "Formamos niños y niñas que sean sociables, creativos, curiosos, responsables, seguros, solidarios y capaces de trabajar en grupo. Al finalizar el nivel:\n• Resuelven problemas simples\n• Se inician en lectura y escritura\n• Se expresan a través del arte, el cuerpo y el juego\n• Desarrollan autonomía y conciencia ambiental",
      },
      {
        heading: "Perfil docente",
        text: "Docentes afectuosos, creativos, comprometidos y en diálogo constante con las familias.",
      },
    ],
  },
  primario: {
    title: "Nivel Primario",
    subtitle: "Excelencia académica con enfoque en valores e inglés intensivo.",
    color: "brand-green",
    content: [
      {
        heading: "Propuesta Pedagógica",
        text: "En el Nivel Primario entendemos que cada estudiante aprende de acuerdo a sus posibilidades y aporta activamente al proceso de enseñanza-aprendizaje en un marco de intercambio. Nuestra enseñanza está orientada al desarrollo integral, favoreciendo actitudes y valores que permitan a los niños y niñas interactuar adecuadamente en la sociedad.",
      },
      {
        heading: "Enfoque",
        text: "Cada estudiante es protagonista de su aprendizaje en un entorno de intercambio y respeto.",
      },
      {
        heading: "Objetivos principales",
        text: "• Desarrollo emocional equilibrado\n• Autonomía y habilidades sociales\n• Comunicación en español e inglés\n• Interés científico y tecnológico\n• Construcción de ciudadanía",
      },
      {
        heading: "Perfil del estudiante",
        text: "Responsable, participativo, respetuoso, curioso, solidario y comprometido con su aprendizaje y su comunidad.",
      },
      {
        heading: "Perfil docente",
        text: "Profesionales comprometidos, reflexivos, con capacidad de acompañar, evaluar y adaptarse a cada contexto.",
      },
    ],
  },
  secundario: {
    title: "Nivel Secundario",
    subtitle: "Formación ciudadana y preparación pre-universitaria con certificaciones internacionales.",
    color: "brand-blue",
    content: [
      {
        heading: "Nuestra propuesta",
        text: "La Escuela Secundaria de la Fundación Educativa Esquel nació en 2020 como respuesta a la demanda educativa de la ciudad. Con un Ciclo Básico Común y un Ciclo Orientado en Ciencias Naturales, se proyecta hacia el futuro ofreciendo una propuesta innovadora y de calidad.\n\nNuestra propuesta se basa en:\n• Formación integral\n• Acompañamiento personalizado\n• Excelencia en idiomas\n• Cultura de diálogo y pensamiento crítico",
      },
      {
        heading: "Enfoque pedagógico",
        text: "Aprendizaje activo, colaborativo y contextualizado, respetando los distintos ritmos.",
      },
      {
        heading: "Perfil del egresado",
        text: "Formamos estudiantes que piensan críticamente, se comunican con claridad, trabajan en equipo y actúan con responsabilidad.",
      },
      {
        heading: "Comunidad educativa",
        text: "• Docentes: Nuestros docentes se distinguen por enseñar con compromiso y creatividad, seleccionar contenidos relevantes, diseñar aprendizajes significativos y promover el desarrollo integral de los estudiantes en vínculo con las familias.\n• Familias: Las familias son parte activa: acompañan el desarrollo de sus hijos, refuerzan valores, participan en la vida institucional y mantienen una comunicación respetuosa con la escuela.\n• Personal Auxiliar: El personal auxiliar es fundamental porque representa valores, promueve el trabajo en equipo y apoya con compromiso las tareas educativas y administrativas.",
      },
    ],
  },
};

type Params = { nivel: string };

export async function generateMetadata({ params }: { params: Promise<Params> }): Promise<Metadata> {
  const resolvedParams = await params;
  const data = nivelesData[resolvedParams.nivel as keyof typeof nivelesData];
  if (!data) return { title: "No encontrado" };
  return {
    title: `${data.title} | Fundación Educativa Esquel`,
    description: data.subtitle,
  };
}

// Para SSG (Static Site Generation)
export function generateStaticParams() {
  return [{ nivel: "inicial" }, { nivel: "primario" }, { nivel: "secundario" }];
}

export default async function NivelPage({ params }: { params: Promise<Params> }) {
  const resolvedParams = await params;
  const nivel = resolvedParams.nivel;
  const data = nivelesData[nivel as keyof typeof nivelesData];

  if (!data) notFound();

  const colorClassMap = {
    "brand-yellow": "bg-brand-yellow text-brand-blue",
    "brand-green": "bg-brand-green text-white",
    "brand-blue": "bg-brand-blue text-white",
  };

  return (
    <div className="bg-background pb-24">
      {/* Dynamic Header */}
      <section className={`pt-32 pb-20 ${colorClassMap[data.color as keyof typeof colorClassMap]}`}>
        <div className="container mx-auto px-6 lg:px-12 relative z-10">
          <span className="font-bold uppercase tracking-widest text-sm mb-4 block opacity-80">
            Propuesta Educativa
          </span>
          <h1 className="text-4xl sm:text-5xl md:text-6xl font-bold mb-6 max-w-4xl leading-tight">
            {data.title}
          </h1>
          <p className="text-xl max-w-2xl leading-relaxed opacity-90">
            {data.subtitle}
          </p>
        </div>
      </section>

      {/* Content Blocks */}
      <section className="py-16 md:py-24">
        <div className="container mx-auto px-6 lg:px-12 grid grid-cols-1 lg:grid-cols-2 gap-8 lg:gap-16 items-start">
          
          <div className="flex flex-col gap-12">
            {data.content.map((block, i) => (
              <div key={i} className="group">
                <div className="h-1 w-12 bg-current opacity-20 mb-6 group-hover:w-24 transition-all duration-300" />
                <h2 className="text-3xl font-bold text-brand-blue mb-4">
                  {block.heading}
                </h2>
                <p className="text-lg text-brand-foreground/80 leading-relaxed whitespace-pre-line">
                  {block.text}
                </p>
              </div>
            ))}
          </div>

          <div className="sticky top-32 flex flex-col gap-8">
            <div className="bg-white p-12 rounded-[2rem] shadow-xl border border-brand-gray/5">
              <h3 className="text-2xl font-bold text-brand-blue mb-4">
                Consulta por Vacantes {new Date().getFullYear() + 1}
              </h3>
              <p className="text-brand-foreground/70 mb-8">
                El proceso de admisión para {data.title} se encuentra abierto a toda la comunidad de Esquel y zona de influencia. Te invitamos a postularte.
              </p>
              <a href="/inscripciones" className={`inline-block w-full text-center px-6 py-4 rounded-full font-bold shadow-md hover:-translate-y-1 transition-all ${colorClassMap[data.color as keyof typeof colorClassMap]}`}>
                Llenar Formulario de Admisión
              </a>
            </div>

            <div className="bg-brand-gray/5 p-12 rounded-[2rem] text-center border border-brand-gray/10">
              <span className="text-brand-lightblue text-sm font-bold uppercase tracking-wider mb-2 block">Contacto Directo</span>
              <p className="font-semibold text-brand-blue">escuelafeesquel@gmail.com</p>
              <p className="text-brand-foreground/70 text-sm mt-2">(02945) 456053</p>
            </div>
          </div>

        </div>
      </section>

    </div>
  );
}
